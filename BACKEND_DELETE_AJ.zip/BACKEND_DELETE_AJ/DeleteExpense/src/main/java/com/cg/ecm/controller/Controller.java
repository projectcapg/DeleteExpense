package com.cg.ecm.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ecm.dao.DeleteRepository;
import com.cg.ecm.dto.ExpenseClaimed;
import com.cg.ecm.exception.IDException;
import com.cg.ecm.service.DeleteService;


@RestController
@CrossOrigin(origins="http://localhost:4200")
public class Controller {

	@Autowired
	DeleteService ser;
	@Autowired
	DeleteRepository rep;
	
	@DeleteMapping(path="/deleteExpense/{id}")
	public void deleteUser(@PathVariable("id") int uId) throws IDException  {
		
		System.out.println("Wegot id:"+ser.searchId(uId));
		if(ser.searchId(uId)==1)
		{
			ser.deleteById(uId);
			System.out.println("Data Deleted");
		}
		else
		{
			System.out.println("Invalid Data");
			throw new IDException("Invalid ID provided");
		}
		
	}
	
	
	
	@GetMapping("/expenseclaim/search/{uid}")
	public ExpenseClaimed searchUserById(@PathVariable("uid") int id) throws IDException 
	{
		ExpenseClaimed lgg = ser.searchID(id);
		if(lgg==null)
		{
			throw new IDException("No user with this ID "+id);
		}
		else
		{
			return lgg;
		}
	}
	
}

