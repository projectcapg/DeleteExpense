package com.cg.ecm.exception;

public class IDException extends Exception{

	public IDException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public IDException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public IDException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public IDException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public IDException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	

}
