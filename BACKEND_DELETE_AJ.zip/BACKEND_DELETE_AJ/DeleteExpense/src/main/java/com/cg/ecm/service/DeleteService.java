package com.cg.ecm.service;

import org.springframework.stereotype.Service;

import com.cg.ecm.dto.ExpenseClaimed;
import com.cg.ecm.exception.IDException;

@Service
public interface DeleteService {

	public int searchId(int id) throws IDException;
	public ExpenseClaimed deleteById(int id);
	public ExpenseClaimed searchID(int id);
}
