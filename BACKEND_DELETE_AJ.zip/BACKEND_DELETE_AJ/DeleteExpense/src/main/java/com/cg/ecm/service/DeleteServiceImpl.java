package com.cg.ecm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ecm.dao.DeleteRepository;
import com.cg.ecm.dto.ExpenseClaimed;
import com.cg.ecm.exception.IDException;

@Service
public class DeleteServiceImpl implements DeleteService{

	@Autowired
	DeleteRepository dao;
	
	@Override
	public ExpenseClaimed deleteById(int id) {
		ExpenseClaimed ec=dao.findById(id).get();
		dao.deleteById(id);
		
		return ec;
	}
	
	@Override
	public int searchId(int id) throws IDException
	{
		if(dao.findById(id).isPresent())
		{
			System.out.println("aaaaaaaaaaaaaaaaaaaaaaaaaaa");
			return 1;
		}
		else
		{
			System.out.println("bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb");
			return 0;
		}
		
	}
	
	@Override
	public ExpenseClaimed searchID(int id) {
		// TODO Auto-generated method stub
		return dao.findById(id).get();
	}
		

}
