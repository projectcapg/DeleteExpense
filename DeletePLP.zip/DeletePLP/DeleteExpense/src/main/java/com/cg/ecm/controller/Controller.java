package com.cg.ecm.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

import com.cg.ecm.dao.DeleteRepository;
import com.cg.ecm.dto.ExpenseClaimed;
import com.cg.ecm.service.DeleteService;

@RestController
@CrossOrigin(origins = "http://localhost:4200")
public class Controller {

	@Autowired
	DeleteService ser;
	@Autowired
	DeleteRepository rep;

	@DeleteMapping(path = "/deleteExpense/{id}")
	public ExpenseClaimed deleteUser(@PathVariable("id") int uId) {
		if(rep.findById(uId).isPresent()) {
			ExpenseClaimed expClm = rep.findById(uId).get();
			ser.deleteById(uId);
			return expClm;
		}
		return null;
	}

}
