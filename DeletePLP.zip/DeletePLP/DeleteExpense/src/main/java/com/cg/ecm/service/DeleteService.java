package com.cg.ecm.service;

import org.springframework.stereotype.Service;

import com.cg.ecm.dto.ExpenseClaimed;

@Service
public interface DeleteService {

	public void deleteById(int id);
}
