package com.cg.ecm.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.ecm.dao.DeleteRepository;
import com.cg.ecm.dto.ExpenseClaimed;

@Service
public class DeleteServiceImpl implements DeleteService{

	@Autowired
	DeleteRepository dao;
	
	@Override
	public void deleteById(int id){
		dao.deleteById(id);
	}

}
