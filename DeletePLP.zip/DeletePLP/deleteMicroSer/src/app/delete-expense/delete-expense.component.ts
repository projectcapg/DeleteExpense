import { Component, OnInit } from '@angular/core';
import { ExpenseDeleteService } from '../service/expense-delete.service';
import { Delete } from '../model/delete';

@Component({
  selector: 'app-delete-expense',
  templateUrl: './delete-expense.component.html',
  styleUrls: ['./delete-expense.component.css']
})
export class DeleteExpenseComponent implements OnInit {
  del: string ;
  submitted = false;
  constructor(private expService: ExpenseDeleteService) { }

  ngOnInit() {
  }

  deleteExpense(id: number) {
    this.submitted = true;
    this.expService.deleteExpence(id).subscribe(del => {
      if(del!=null){
        this.del = 'Successful Deletion';
      }else{
        this.del = "Invalid ID";
      }
    });
  }
}
