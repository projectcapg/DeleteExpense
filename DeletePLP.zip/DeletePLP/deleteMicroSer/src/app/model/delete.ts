export class Delete {

    employeeId: number;
    projectCode: number;
    expenseCode: number;
    startDate: Date;
	endDate: Date;
    expenseAmount: number;
}
