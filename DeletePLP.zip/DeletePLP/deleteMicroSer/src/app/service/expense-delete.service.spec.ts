import { TestBed } from '@angular/core/testing';

import { ExpenseDeleteService } from './expense-delete.service';

describe('ExpenseDeleteService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: ExpenseDeleteService = TestBed.get(ExpenseDeleteService);
    expect(service).toBeTruthy();
  });
});
