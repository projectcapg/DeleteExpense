import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Delete } from '../model/delete';
import { Observable } from 'rxjs';
const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};
@Injectable({
  providedIn: 'root'
})
export class ExpenseDeleteService {

  customer: string;
  url = 'http://localhost:1112/deleteExpense';
  constructor(private http: HttpClient) {
  }

  deleteExpence(id: number): Observable<Delete> {
       return  this.http.delete<Delete>(`${this.url}/${id}`, httpOptions);
  }

}
